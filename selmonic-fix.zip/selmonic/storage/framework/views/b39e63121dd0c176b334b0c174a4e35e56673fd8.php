<?php $__env->startSection('title'); ?>
    Store Dashboard Product Create
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-content section-dashboard-home" data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title">Add New Product</h2>
                <p class="dashboard-subtitle">Create your own product</p>
            </div>
            <div class="dashboard-content mt-5">
                <div class="row">

                    
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success col-md-12">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger col-md-12">
                            <?php echo e(session()->get('error')); ?>

                        </div>
                    <?php endif; ?>



                    <div class="col-12">
                        <form
                            action="<?php echo e(isset($article) ? route('admin.article.update', $article->id) : route('admin.article.store')); ?>"
                            method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($article)): ?>
                                <?php echo method_field('put'); ?>
                            <?php endif; ?>
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="title">Title</label>
                                                <input type="text" class="form-control" id="title"
                                                    aria-describedby="title" name="title"
                                                    value="<?php echo e(isset($article) ? $article->title : ''); ?>" />
                                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="name">Slug Name</label>
                                                <input type="text" class="form-control" id="slug"
                                                    aria-describedby="name" name="slug"
                                                    value="<?php echo e(isset($article) ? $article->slug : ''); ?>" />
                                                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="author">Author</label>
                                                <input type="text" class="form-control" id="author"
                                                    aria-describedby="author" name="author"
                                                    value="<?php echo e(isset($article) ? $article->author : ''); ?>" />
                                                <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="is_on_landing">Show in Landing Page</label>
                                                <select name="is_on_landing" id="is_on_landing" class="form-control">
                                                    <option value="0"
                                                        <?php echo e(isset($article) ? ($article->is_on_landing == 0 ?: 'selected') : ''); ?>>
                                                        No</option>
                                                    <option value="1"
                                                        <?php echo e(isset($article) ? ($article->is_on_landing == 1 ?: 'selected') : ''); ?>>
                                                        Yes</option>
                                                </select>
                                                <?php $__errorArgs = ['is_on_landing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="description">Description</label>
                                                <textarea id="editor" name="description">
                                                    <?php echo e(isset($article) ? $article->description : ''); ?>

                                                </textarea>
                                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="image">Thumbnail</label>
                                                <?php if(isset($article)): ?>
                                                    <br>
                                                    <img src="<?php echo e(asset($article->image)); ?>" alt=""
                                                        class="img-thumbnail img-fluid my-4" width="400">
                                                <?php endif; ?>
                                                <input type="file" multiple class="form-control pt-1" id="image"
                                                    aria-describedby="image" name="image" />
                                                <small class="text-muted">
                                                    Pilih gambar utama dari produk yang kamu jual.
                                                </small>
                                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <button type="submit" class="btn btn-success btn-block px-5">
                                        Save Now
                                    </button>
                                    <br>
                                    <br>
                                    <br>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-script'); ?>
    <script src="https://cdn.ckeditor.com/4.21.0/standard/ckeditor.js"></script>

    <script>
        CKEDITOR.replace("editor");

        const name = document.querySelector('#title');
        const slug = document.querySelector('#slug');

        name.addEventListener('change', function() {
            fetch('/admin/article/cekSlug?name=' + name.value)
                .then(response => response.json())
                .then(data => slug.value = data.slug)
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 5\TA\Project gue\Selmonic fix\selmonic\resources\views/pages/admin/articles/form.blade.php ENDPATH**/ ?>