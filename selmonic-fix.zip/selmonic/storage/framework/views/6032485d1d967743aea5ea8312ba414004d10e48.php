<?php $__env->startSection('title'); ?>
    Store Dashboard Product Variant Create
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-content section-dashboard-home" data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title">Add New Variant Product</h2>
                <p class="dashboard-subtitle">Create your own variant product</p>
            </div>
            <div class="dashboard-content mt-5">
                <div class="row">

                    
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success col-md-12">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger col-md-12">
                            <?php echo e(session()->get('error')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="col-12">
                        <form
                            action="<?php echo e(isset($variant) ? route('admin.product.variant.update', $variant->id) : route('admin.product.variant.store', $product->id)); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($variant)): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>
                            <div class="card">
                                <div class="card-body">
                                    <h5>Product : <?php echo e(isset($variant) ? $variant->product->name : $product->name); ?>

                                    </h5>
                                    <div class="row mt-3">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="name">Name</label>
                                                <input type="text" class="form-control" id="name"
                                                    aria-describedby="name" name="name" value="<?php echo e(isset($variant) ? $variant->name : ""); ?>" />
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="price">Price</label>
                                                <input type="number" class="form-control" id="price"
                                                    aria-describedby="price" name="price" value="<?php echo e(isset($variant) ? $variant->price : ""); ?>" />
                                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="stock">Stock</label>
                                                <input type="number" class="form-control" id="stock"
                                                    aria-describedby="stock" name="stock" value="<?php echo e(isset($variant) ? $variant->stock : ""); ?>" />
                                                <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="weight">Berat (Satuan Gram)</label>
                                                <input type="number" class="form-control" id="weight"
                                                    aria-describedby="weight" name="weight"
                                            value="<?php echo e(isset($variant) ? $variant->weight : ""); ?>" />
                                                <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <a href="<?php echo e(route('admin.product.show', isset($variant) ? $variant->product->id : $product->id)); ?>"
                                        class="btn btn-secondary btn-block px-5">
                                        Back
                                    </a>
                                    <button type="submit" class="btn btn-success btn-block px-5">
                                        Save Now
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-script'); ?>
    <script src="https://cdn.ckeditor.com/4.21.0/standard/ckeditor.js"></script>

    <script>
        CKEDITOR.replace("editor");

        const name = document.querySelector('#name');
        const slug = document.querySelector('#slug');

        name.addEventListener('change', function() {
            fetch('/admin/product/cekSlug?name=' + name.value)
                .then(response => response.json())
                .then(data => slug.value = data.slug)
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 5\TA\Project gue\TryValet\selmonic\resources\views/pages/admin/products/variant-form.blade.php ENDPATH**/ ?>