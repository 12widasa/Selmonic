<?php $__env->startSection('title'); ?>
    Store Dashboard Article
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-content section-dashboard-home" data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title">My Article</h2>
                <p class="dashboard-subtitle">
                    List of My Article
                </p>
            </div>
            <div class="dashboard-content">
                <div class="row">
                    <div class="col-12">
                        <a href="<?php echo e(route('admin.article.create')); ?>" class="btn btn-success">Add Article</a>
                    </div>
                </div>
                <div class="row mt-4 card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Author</th>
                                        <th scope="col">Title</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Handle</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <th scope="row">
                                                <?php echo e($loop->iteration); ?>

                                            </th>
                                            <td>
                                                <?php echo e(Carbon\Carbon::parse($item->created_at)->format('d, F Y')); ?>

                                            </td>
                                            <td>
                                                <img src="<?php echo e(asset($item->image)); ?>" alt="" style="width: 150px"
                                                    class="img-thumbnail" />
                                            </td>
                                            <td>
                                                <?php echo e($item->author); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->title); ?>

                                            </td>
                                            <td>
                                                <?php echo $item->description; ?>

                                            </td>
                                            <td>
                                                <div class="d-flex gap-2 text-center">
                                                    <a href="<?php echo e(route('admin.article.edit', $item->id)); ?>"
                                                        class="btn btn-warning btn-sm" type="button">Edit</a>
                                                    <form action="<?php echo e(route('admin.article.destroy', $item->id)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm"
                                                            type="button">Delete</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <th colspan="7" class="text-center py-3 text-secondary">Belum ada data
                                                artikel</th>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 5\TA\Project gue\Selmonic fix\selmonic\resources\views/pages/admin/articles/index.blade.php ENDPATH**/ ?>