<?php $__env->startSection('title'); ?>
    Store Dashboard Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-content section-dashboard-home" data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title">My Category</h2>
                <p class="dashboard-subtitle">
                    List of My Category
                </p>
            </div>
            <div class="dashboard-content">
                <div class="row">
                    <div class="col-12">
                        <a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-success">Add Category</a>
                    </div>
                </div>
                <div class="row mt-4 card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Category</th>
                                        <th scope="col">Handle</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                                            <td width="70%">
                                                <?php echo e($item->name); ?>

                                            </td>
                                            <td>
                                                <div class="d-flex gap-2 text-center">
                                                    <a href="<?php echo e(route('admin.category.edit', $item->id)); ?>"
                                                        class="btn btn-warning btn-sm" type="button">Edit</a>
                                                    <form action="<?php echo e(route('admin.category.destroy', $item->id)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm"
                                                            type="button">Delete</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <th colspan="3" class="text-center py-3 text-secondary">Belum ada data
                                                category</th>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 5\TA\Project gue\TryValet\selmonic\resources\views/pages/admin/categories/index.blade.php ENDPATH**/ ?>