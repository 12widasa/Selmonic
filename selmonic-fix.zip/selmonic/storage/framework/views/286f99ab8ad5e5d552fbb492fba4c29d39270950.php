    <nav class="navbar navbar-expand-lg bg-nav navbar-store fixed-top navbar-fixed-top" data-aos="fade-down">
        <div class="container">
            <a href="<?php echo e(route('home')); ?>" class="navbar-brand text-white">
                <img src="/images/Logo Arga Hidroponik.svg" alt="Logo" />
                <span class="fw-semibold">ARGHA HIDROPONIK</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item active">
                        <a href="<?php echo e(route('home')); ?>" class="nav-link text-white">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('shop')); ?>" class="nav-link text-white">Shop</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('picsort')); ?>" class="nav-link text-white">PicSort</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('article.index')); ?>" class="nav-link text-white">Articles</a>
                    </li>
                    <?php if(!auth()->user()): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('register')); ?>" class="nav-link text-white">Sign up</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-success nav-link text-white px-4">Sign in</a>
                    </li>
                    <?php endif; ?>
                </ul>

                <?php if(auth()->guard()->check()): ?>


                <!-- Dekstop Menu -->
                <ul class="navbar-nav d-none d-lg-flex align-items-center">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <?php if(auth()->user()->photo): ?>
                            <img src="<?php echo e(asset(auth()->user()->photo)); ?>" alt="user" class="rounded-circle me-2 profile-picture" style="width: 40px; height:40px; background-size: cover" />
                            <?php else: ?>
                            <img src="https://cdn5.vectorstock.com/i/1000x1000/73/54/blank-photo-icon-vector-29557354.jpg" alt="user" class="rounded-circle me-2 profile-picture" style="width: 40px; height:40px; background-size: cover" />
                            <?php endif; ?>
                            Hi, <?php echo e(auth()->user()->name); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="<?php echo e(route('user.transaction.index')); ?>" class="dropdown-item">My Transactions</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('user.profile')); ?>" class="dropdown-item">Settings</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider" />
                            </li>
                            <li>
                                <form action="<?php echo e(route('logout')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">Logout</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('cart.index')); ?>" class="nav-link d-inline-block position-relative">
                            <?php if(auth()->user()->carts->count() > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-secondary">
                                <?php echo e(auth()->user()->carts->count()); ?>

                                <span class="visually-hidden">My Cart</span>
                            </span>
                            <?php endif; ?>
                            <img src="/images/icon-cart-empty.svg" alt="" />
                        </a>
                    </li>
                </ul>

                <!-- mobile -->
                <ul class="navbar-nav d-block d-lg-none">
                    <li class="nav-item">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <?php if(auth()->user()->photo): ?>
                            <img src="<?php echo e(asset(auth()->user()->photo)); ?>" alt="user" class="rounded-circle me-2 profile-picture" style="width: 40px; height:40px; background-size: cover" />
                            <?php else: ?>
                            <img src="https://cdn5.vectorstock.com/i/1000x1000/73/54/blank-photo-icon-vector-29557354.jpg" alt="user" class="rounded-circle me-2 profile-picture" style="width: 40px; height:40px; background-size: cover" />
                            <?php endif; ?>
                            Hi, <?php echo e(auth()->user()->name); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="<?php echo e(route('user.transaction.index')); ?>" class="dropdown-item">My Transactions</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('user.profile')); ?>" class="dropdown-item">Settings</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider" />
                            </li>
                            <li>
                                <form action="<?php echo e(route('logout')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">Logout</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                </ul>

                <?php endif; ?>
            </div>
        </div>
    </nav><?php /**PATH D:\SMT 5\TA\Project gue\Selmonic fix\selmonic\resources\views/includes/navbar.blade.php ENDPATH**/ ?>