<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- style -->
    <?php echo $__env->yieldPushContent('prepend-style'); ?> <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php echo $__env->yieldPushContent('addon-style'); ?>
</head>

<body>
    <!-- Loading screen -->
    <div class="loading d-none" data-aos="fade-down">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    <?php echo $__env->make('layouts.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- navbar -->
    <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- page content -->
    <?php echo $__env->yieldContent('content'); ?>


    <!-- footer 1 -->
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- script -->
    <?php echo $__env->yieldPushContent('prepend-script'); ?> <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php echo $__env->yieldPushContent('addon-script'); ?>
</body>

</html>
<?php /**PATH D:\SMT 5\TA\Project gue\Selmonic fix\selmonic\resources\views/layouts/app.blade.php ENDPATH**/ ?>