<div aria-live="polite" aria-atomic="true" class="position-relative">
    <div class="toast-container top-0 end-0 p-3">

        <!-- Then put toasts within -->
        <?php if(session()->has('success')): ?>
            <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header bg-success">
                    <strong class="me-auto text-white">Success</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    <?php echo e(session()->get('success')); ?>

                </div>
            </div>
        <?php endif; ?>

        <?php if(session()->has('error')): ?>
            <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header bg-danger">
                    <strong class="me-auto text-white">Error !</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    <?php echo e(session()->get('error')); ?>

                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /Users/macbookpro/Documents/selmonic/resources/views/layouts/toast.blade.php ENDPATH**/ ?>