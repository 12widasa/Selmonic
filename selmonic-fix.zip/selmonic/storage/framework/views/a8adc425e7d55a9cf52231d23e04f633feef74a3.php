<?php $__env->startSection('title'); ?>
    Store Homepage
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="dashboard-user mt-5" style="min-height: 60vh">
        <br>
        <br>
        <br>
        <div class="container">
            <div class="row align-items-start">
                <div class="col-12">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 mt-2 mb-5">
                                <h5 class="mb-3">My Transactions</h5>
                                <?php
                                $item_selected = 0;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="card card-list d-block mb-3">
                                        <div class="card-body">
                                            <div class="row ms-5">
                                                <div class="col-md-2">
                                                    <?php echo e($transaction->created_at); ?>

                                                </div>
                                                <div class="col-md-2">
                                                    <?php echo e($transaction->invoice_code); ?>

                                                    <br>
                                                    <?php if($transaction->payment_status == 'pending'): ?>
                                                        <a target="blank" href="<?php echo e($transaction->midtrans_url); ?>"
                                                            class="text-danger">Bayar
                                                            Sekarang</a>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-md-2">
                                                    <span>Status Pembayaran</span>
                                                    <br>
                                                    <span
                                                        class="text-uppercase <?php if($transaction->payment_status === 'paid'): ?> text-success <?php endif; ?> <?php if($transaction->payment_status === 'pending'): ?> text-warning <?php endif; ?>">
                                                        <?php echo e($transaction->payment_status); ?>

                                                    </span>
                                                </div>
                                                <div class="col-md-2">
                                                    <span>Status Pengiriman</span>
                                                    <br>
                                                    <span
                                                        class="text-uppercase <?php if($transaction->shipping_status === 'success'): ?> text-success <?php endif; ?> <?php if($transaction->shipping_status === 'pending' or $transaction->shipping_status === 'shipping'): ?> text-warning <?php endif; ?> ">
                                                        <?php echo e($transaction->shipping_status); ?>

                                                    </span>
                                                </div>

                                                <div class="col-md-2">
                                                    Rp. <?php echo e(number_format($transaction->total_price)); ?>

                                                </div>
                                                <a href="<?php echo e(route('user.transaction.show', $transaction->id)); ?>"
                                                    class="col-md-1 d-none d-md-block">
                                                    <img src="/images/dashboard-arrow-right.svg" alt="" />
                                                </a>

                                                <?php if($transaction->shipping_status == 'shipping'): ?>
                                                    <?php $item_selected = $transaction->id; ?>
                                                    <a data-bs-toggle="modal" data-bs-target="#terimaPesananModal"
                                                        type="submit" class="col-md-1 d-none d-md-block text-success">
                                                        <img src="/images/check.svg" alt="" />
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="card card-list d-block" href="/dashboard-transactions-details.html">
                                        <div class="card-body text-center">
                                            <p>Yah sepertinya kamu belum melakukan transaksi apapun, yuk bisa segera
                                                checkout !</p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- Modal Verif Terima Pesanan-->
        <div class="modal fade" id="terimaPesananModal" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body text-center p-5">
                        <h4>Yakin anda telah menerima pesanan ?</h4>
                        <div class="mt-5 d-flex justify-content-center gap-2">
                            <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Belum!</button>
                            <form action="<?php echo e(route('user.transaction.acceptShipping', $item_selected)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-success">Ya, saya telah menerima!</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 5\TA\Project gue\TryValet\selmonic\resources\views/pages/transaction.blade.php ENDPATH**/ ?>