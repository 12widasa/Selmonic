<!-- Sidebar -->
<div class="border-right" id="sidebar-wrapper">
    <div class="sidebar-heading text-center">
        <img src="/images/dashboard-store-logo.svg" alt="" class="my-4" />
    </div>
    <div class="list-group list-group-flush">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="list-group-item list-group-item-action ">Dashboard</a>
        <a href="<?php echo e(route('admin.category.index')); ?>" class="list-group-item list-group-item-action">Category Product</a>
        <a href="<?php echo e(route('admin.product.index')); ?>" class="list-group-item list-group-item-action">My
            Products</a>
        <a href="<?php echo e(route('admin.transaction.index')); ?>" class="list-group-item list-group-item-action">Transactions</a>
        <a href="<?php echo e(route('admin.article.index')); ?>" class="list-group-item list-group-item-action">Article</a>
        <a href="<?php echo e(route('admin.controlling.show')); ?>" class="list-group-item list-group-item-action">Controlling Page</a>
    </div>
</div>
<!-- /#sidebar-wrapper --><?php /**PATH D:\SMT 5\TA\Project gue\TryValet\selmonic\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>