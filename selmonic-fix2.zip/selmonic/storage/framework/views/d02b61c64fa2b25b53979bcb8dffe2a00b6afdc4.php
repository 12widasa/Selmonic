<?php $__env->startSection('title'); ?>
    Store Detail Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content page-details">
        <section class="store-breadcumbs" data-aos="fade-down" data-aos-delay="100">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/index.html">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Product Details
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>

        <!-- store-gallery -->

        <section class="store-gallery" id="gallery">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8" data-aos="zoom-in">
                        <transition name="slide-fade" mode="out-in">
                            <img :key="photos[activePhoto].id" :src="photos[activePhoto].url" class="w-100 main-image"
                                alt="" style="max-height: 600px; object-fit: cover" />
                        </transition>
                    </div>
                    <div class="col-lg-2">
                        <div class="row">
                            <div class="col-3 col-lg-12 mt-2 mt-lg-0" v-for="(photo, index) in photos"
                                :key="photo.id" data-aos="zoom-in" data-aos-delay="100">
                                <a href="#" @click="changeActive(index)">
                                    <img :src="photo.url" class="w-100 thumbnail-image"
                                        :class="{ active: index == activePhoto }" alt=""
                                        style="max-height: 150px; object-fit: cover" />
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- store-details-container -->
        <div class="store-details-container" data-aos="fade-up">
            <section class="store-heading">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8">
                            <h1><?php echo e($product->name); ?></h1>

                            <?php if($product->variants->isNotEmpty()): ?>
                                <div class="owner mt-4">Variants :</div>
                                <div class="row my-3">
                                    <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4 mb-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h6><?php echo e($variant->name); ?></h6>
                                                    <div class="owner">Stock Ready : <?php echo e($variant->stock); ?></div>
                                                    <div class="owner">Berat Produk : <?php echo e($variant->weight); ?> Gram</div>
                                                    <div class="price">Rp. <?php echo e(number_format($variant->price)); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div class="owner">Stock Ready : <?php echo e($product->stock); ?></div>
                                <div class="owner">Berat Produk : <?php echo e($product->weight); ?> Gram</div>
                                <div class="price">Rp. <?php echo e(number_format($product->price)); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-2 text-center" data-aos="zoom-in">
                            <?php if($product->variants->isNotEmpty()): ?>
                                <a class="btn btn-content px-4 text-white btn-block mb-3" data-bs-toggle="modal"
                                    data-bs-target="#addCartModal">Add to
                                    Cart
                                </a>
                            <?php else: ?>
                                <?php if($product->stock > 0): ?>
                                    <a class="btn btn-content px-4 text-white btn-block mb-3" data-bs-toggle="modal"
                                        data-bs-target="#addCartModal">Add to
                                        Cart
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </section>
            <section class="store-description mt-3">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-lg-8">
                            <h5>Description</h5>
                            <?php echo $product->description; ?>

                        </div>
                    </div>
                </div>
            </section>
            <section class="store-review">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-lg-8 mt-3 mb-3">
                            <h5>Customer Review (<?php echo e(count($product->reviews)); ?>)</h5>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-lg-8">
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="media mb-3">
                                        <?php if($item->user->photo): ?>
                                            <img src="<?php echo e(asset($item->user->photo)); ?>" class="me-3 rounded-circle"
                                                alt="" style="width: 40px; height:40px; background-size: cover" />
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('images/icon-user.png')); ?>" class="me-3 rounded-circle"
                                                alt="" style="width: 40px; height:40px; background-size: cover" />
                                        <?php endif; ?>

                                        <div class="media-body">
                                            <h5 class="mt-2 mb-1"><?php echo e($item->user->name); ?></h5>
                                            <?php echo e($item->messages); ?>

                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="addCartModal" tabindex="-1" aria-labelledby="addCartModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form action="<?php echo e(route('cart.store', $product->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="btn-close-modal" @click="closeModal()">
                        <img src="<?php echo e(asset('images/icon-delete.svg')); ?>" width="35px" height="35px">
                    </div>
                    <div class="modal-body ">
                        <div class="d-flex">
                            <img src="<?php echo e(asset($product->galleries[0]->image)); ?>" class="rounded-3"
                                style="width: 100px; height: 100px; object-fit: cover; object-position: center;">
                            <div class="ms-3 align-self-end">
                                <h6><?php echo e($product->name); ?></h6>
                                <?php if($product->variants->isEmpty()): ?>
                                    <p>Stock: <?php echo e($product->stock); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php if($product->variants->isNotEmpty()): ?>
                        <hr style="margin-top: -10px !important">
                        <div class="modal-body">
                            <p>Variasi :</p>

                            <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label>
                                    <input type="radio" name="variant_id" class="card-input-variant"
                                        value="<?php echo e($item->id); ?>" @click="setVariant(<?php echo e($item); ?>)"
                                        <?php if($item->stock == 0): echo 'disabled'; endif; ?>>
                                    <div class="d-flex">
                                        <div
                                            class="card card-variant <?php if($item->stock == 0): ?> bg-secondary <?php endif; ?>">
                                            <div class="card-body">
                                                <?php echo e($item->name); ?>

                                            </div>
                                        </div>
                                    </div>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php $__errorArgs = ['variant_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <small><?php echo e($message); ?></small>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endif; ?>
                    <hr style="margin-top: -5px !important">
                    <div id="qty-modal" class="modal-body qty <?php if(count($product->variants) > 0): ?> d-none <?php endif; ?>">
                        <div class="d-flex justify-content-between">
                            <p>Jumlah</p>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-sm btn-minus btn-secondary"
                                    @click="decrement()">-</button>
                                <input type="text" name="quantity" class="form-control text-center" readonly
                                    :value="qty.value" style="width:55px; height:30px">
                                <button type="button" class="btn btn-sm btn-plus btn-secondary"
                                    @click="increment()">+</button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-content btn-sm text-white">Add to Cart</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <style>
        .btn-close-modal {
            position: absolute;
            top: -10px !important;
            right: -10px !important;
            width: 35px;
            height: 35px;
            cursor: pointer;
        }

        .qty {
            padding: 0 1rem;
        }

        .btn-plus,
        .btn-minus {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            border: 1px solid #e5e5e5;
        }

        .card-input-variant {
            display: none;
        }

        .d-flex .card-variant {
            cursor: pointer;
        }

        .d-flex .card-variant .card-body {
            border-radius: 5px;
            padding: 0.5rem 1rem;
            cursor: pointer;
        }

        .card-input-variant:checked+.d-flex .card-variant {
            background-color: #198754;
            color: #e5e5e5;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <script src="/vendor/vue/vue.js"></script>
    <script>
        var gallery = new Vue({
            el: "#gallery",
            mounted() {
                AOS.init();

            },
            data: {
                activePhoto: 0,
                photos: [

                    <?php $__currentLoopData = $product->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        {
                            id: <?php echo e($gallery->id); ?>,
                            url: "<?php echo e(asset($gallery->image)); ?>",
                        },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],

            },
            methods: {
                changeActive(id) {
                    this.activePhoto = id;
                },
            },
        });

        var cartModal = new Vue({
            el: "#addCartModal",
            data: {
                qty: {
                    value: 1,
                    min: 1,
                    max: <?php echo e($product->stock); ?>,
                },
            },
            methods: {
                increment() {
                    if (this.qty.value < this.qty.max) {
                        this.qty.value++;
                    }

                    console.log(this.qty.max)
                },
                decrement() {
                    if (this.qty.value > this.qty.min) {
                        this.qty.value--;
                    }
                },

                closeModal() {
                    $('#addCartModal').modal('hide');
                },

                setVariant(variant) {
                    this.qty.max = variant.stock;
                    $(`#qty-modal`).removeClass('d-none');
                }
            },
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/Documents/selmonic/resources/views/pages/detail.blade.php ENDPATH**/ ?>