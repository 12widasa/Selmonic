<section class="find-us text-white">
    <h3 class="text-center mb-4">TEMUKAN KAMI</h3>

    <div class="row">
        <div class="col-4 d-flex justify-content-center market">
            <i class="fab fa-whatsapp fa-3x me-md-3 mb-2"></i>
            <div>
                <p class="mb-0">Whatsapp</p>
                <p>081390364269</p>
            </div>
        </div>
        <div class="col-4 d-flex justify-content-center market">
            <i class="fab fa-instagram fa-3x me-md-3 mb-2"></i>
            <div>
                <p class="mb-0">Instagram</p>
                <p>Argha Hidroponik</p>
            </div>
        </div>
        <div class="col-4 d-flex justify-content-center market">
            <i class="fab fa-facebook fa-3x me-md-3 mb-2"></i>
            <div>
                <p class="mb-0">Facebook</p>
                <p>Argha Hidroponik</p>
            </div>
        </div>
    </div>
    <div class="d-flex justify-content-center text-center mt-3 alamat-toko">
        <i class="fas fa-map-marker-alt fa-3x me-3"></i>

        <div>
            <p class="mb-0">
                Jl. arumanis tengah No. 12, rt 04 / RW 02 Kelurahan Tambakaji Kec.
                Ngaliyan Semarang Barat
            </p>
        </div>
    </div>
</section>

<div class="copyright">
    <p>&copy; COPYRIGHT BY SELMONIC POLINES</p>
</div>
<?php /**PATH /Users/macbookpro/Documents/selmonic/resources/views/includes/footer.blade.php ENDPATH**/ ?>