<?php $__env->startSection('title'); ?>
    Store Dashboard Category Create
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-content section-dashboard-home" data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title">Add New Category</h2>
                <p class="dashboard-subtitle">Create your category product</p>
            </div>
            <div class="dashboard-content mt-5">
                <div class="row">

                    
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success col-md-12">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger col-md-12">
                            <?php echo e(session()->get('error')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="col-md-6">
                        <form
                            action="<?php echo e(isset($category) ? route('admin.category.update', $category->id) : route('admin.category.store')); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>

                            <?php if(isset($category)): ?>
                                <?php echo method_field('put'); ?>
                            <?php endif; ?>
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="name">Category Name</label>
                                                <input type="text" class="form-control" id="name"
                                                    aria-describedby="name" name="name"
                                                    value="<?php echo e(isset($category) ? $category->name : ''); ?>" />
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger">
                                                        <small><?php echo e($message); ?></small>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <button type="submit" class="btn btn-success btn-block px-5">
                                        Save Now
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-script'); ?>
    <script src="https://cdn.ckeditor.com/4.21.0/standard/ckeditor.js"></script>

    <script>
        CKEDITOR.replace("editor");

        const name = document.querySelector('#name');
        const slug = document.querySelector('#slug');

        name.addEventListener('change', function() {
            fetch('/admin/product/cekSlug?name=' + name.value)
                .then(response => response.json())
                .then(data => slug.value = data.slug)
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 5\TA\Project gue\Selmonic fix\selmonic\resources\views/pages/admin/categories/form.blade.php ENDPATH**/ ?>