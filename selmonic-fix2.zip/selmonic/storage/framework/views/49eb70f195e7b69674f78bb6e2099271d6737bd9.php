<?php $__env->startSection('title'); ?>
    Store Dashboard Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-content section-dashboard-home" data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title">My Products</h2>
                <p class="dashboard-subtitle">Manage it well and get money</p>
            </div>


            <div class="dashboard-content">
                <div class="row">
                    <div class="col-12">
                        <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-success">Add New Product</a>
                    </div>
                </div>
                <div class="row mt-4">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                            <a class="card card-dashboard-product d-block"
                                href="<?php echo e(route('admin.product.show', $item->id)); ?>">
                                <div class="card-body">
                                    <img src="<?php echo e(isset($item->galleries[0]) ? asset($item->galleries[0]->image) : 'https://clicxy.com/wp-content/uploads/2016/04/dummy-post-horisontal.jpg'); ?>"
                                        alt="" style="height: 200px; object-fit: cover"
                                        class="img-fluid rounded-4 w-100 mb-2" />
                                    <div class="product-title"><?php echo e($item->name); ?></div>
                                    <div class="product-category"><?php echo e($item->category->name); ?></div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center">
                            <p>Anda Belum memiliki produk yang akan dijual</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 5\TA\Project gue\Selmonic fix\selmonic\resources\views/pages/admin/products/index.blade.php ENDPATH**/ ?>