<?php $__env->startSection('title'); ?>
    Shipping Success !
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content page-success">
        <div class="section-success" data-aos="zoom-in">
            <div class="container">
                <div class="row align-items-center row-login justify-content-center">
                    <div class="col-lg-6 ">
                        <div class="text-center">
                            <img src="/images/success.svg" alt="" class="mb-4" />
                            <h2>Yey, Pesanan kamu telah kamu terima !</h2>
                            <p>
                                Silahkan isi form review untuk produk yang kamu beli
                            </p>
                        </div>
                        <div class="mt-4">
                            <form action="<?php echo e(route('user.review.store', $transaction->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="card">
                                    <div class="card-body">
                                        <?php $__errorArgs = ['review.*.message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger my-4">
                                                Pesan wajib diisi
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php $__currentLoopData = $transaction->transactionDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mb-4">
                                                <div class="col-12 d-flex gap-2">
                                                    <img src="<?php echo e(asset($item->product->galleries[0]->image)); ?>"
                                                        style="width:80px; height: 80px; object-fit: cover; object-position: center;"
                                                        class="cart-image rounded-3" />
                                                    <p><?php echo e($item->product->name); ?></p>
                                                </div>
                                                <div class="col-12 mt-2">
                                                    <label for="">Review</label>
                                                    <textarea name="review[<?php echo e($item->product->id); ?>][message]" class="form-control"
                                                        placeholder="Masukkan pesan kamu pada produk ini" required></textarea>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <button type="submit" class="btn btn-success">Kirim Review</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/Documents/selmonic/resources/views/pages/review.blade.php ENDPATH**/ ?>