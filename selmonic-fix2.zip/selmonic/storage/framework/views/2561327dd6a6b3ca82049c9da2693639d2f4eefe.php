    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <div class="d-flex justify-content-between my-2">
                        <h6>Product Variant</h6>
                        <a href="<?php echo e(route('admin.product.variant.create', $product->id)); ?>"
                            class="btn btn-secondary btn-sm " id="btnAddVariant">
                            <i class="fas fa-plus"></i> Add
                        </a>
                    </div>
                    <table class="table table-bordered table-hover">
                        <thead class="table-light">
                            <tr>
                                <td scope="col">#</td>
                                <td scope="col">Name</td>
                                <td scope="col">Price</td>
                                <td scope="col">Stock</td>
                                <td scope="col">Weight</td>
                                <td scope="col"></td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <?php echo e($loop->iteration); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->price); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->stock); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->weight); ?>

                                    </td>
                                    <td align="center">
                                        <div class="dropdown" style="z-index: 9999">
                                            <button class="btn btn-secondary btn-sm" type="button"
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                Action
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a href="<?php echo e(route('admin.product.variant.edit', $item->id)); ?>"
                                                        class="dropdown-item" href="#">Edit</a></li>
                                                <li>
                                                    <form
                                                        action="<?php echo e(route('admin.product.variant.destroy', $item->id)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="dropdown-item"
                                                            href="#">Delete</button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">Product tidak memiliki variant</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH D:\SMT 5\TA\Project gue\TryValet\selmonic\resources\views/pages/admin/products/variant.blade.php ENDPATH**/ ?>