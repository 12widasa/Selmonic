 <nav class="navbar navbar-expand-lg bg-nav navbar-store fixed-top navbar-fixed-top" data-aos="fade-down">
     <div class="container">
         <a href="{{ url('home') }}" class="navbar-brand text-white">
             <img src="/images/Logo Arga Hidroponik.svg" alt="Logo" />
         </a>
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03"
             aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
             <ul class="navbar-nav ms-auto">
                 <li class="nav-item">
                     <a href="{{ url('home') }}" class="nav-link text-white">Home</a>
                 </li>
                 <li class="nav-item">
                     <a href="{{ url('shop') }}" class="nav-link text-white">Shop</a>
                 </li>
                 <li class="nav-item">
                     <a href="#" class="nav-link text-white">Rewards</a>
                 </li>
             </ul>
         </div>
     </div>
 </nav>
